#ifndef HEADER_TYPES
#define HEADER_TYPES

#include <OpenHome/Types.h>

#endif //HEADER_TYPES
