#ifndef HEADER_OHNET_DEFINES
#define HEADER_OHNET_DEFINES

#include <OpenHome/Defines.h>

#endif /* HEADER_OHNET_DEFINES */
